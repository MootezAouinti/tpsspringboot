package com.mootez.vetements.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Vetement {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idVetement;
	private String nomVetement;
	private Double prixVetement;
	private String genreVetement;
	
	@ManyToOne
	private Marque marque;
	
	
	public Vetement() {
		super();
	}
	
	
	public Vetement(String nomVetement, Double prixVetement, String genreVetement) {
		super();
		this.nomVetement = nomVetement;
		this.prixVetement = prixVetement;
		this.genreVetement = genreVetement;
	}


	public Long getIdVetement() {
		return idVetement;
	}
	public void setIdVetement(Long idVetement) {
		this.idVetement = idVetement;
	}
	public String getNomVetement() {
		return nomVetement;
	}
	public void setNomVetement(String nomVetement) {
		this.nomVetement = nomVetement;
	}
	public Double getPrixVetement() {
		return prixVetement;
	}
	public void setPrixVetement(Double prixVetement) {
		this.prixVetement = prixVetement;
	}
	public String getGenreVetement() {
		return genreVetement;
	}
	public void setGenreVetement(String genreVetement) {
		this.genreVetement = genreVetement;
	}


	@Override
	public String toString() {
		return "Vetement [idVetement=" + idVetement + ", nomVetement=" + nomVetement + ", prixVetement=" + prixVetement
				+ ", genreVetement=" + genreVetement + "]";
	}


	public Marque getMarque() {
		return marque;
	}


	public void setMarque(Marque marque) {
		this.marque = marque;
	}
	
	

}
