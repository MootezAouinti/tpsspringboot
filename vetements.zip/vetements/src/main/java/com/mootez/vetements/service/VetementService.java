package com.mootez.vetements.service;

import java.util.List;

import com.mootez.vetements.entities.Marque;
import com.mootez.vetements.entities.Vetement;

public interface VetementService {
	
	Vetement saveVetement(Vetement vet);
	Vetement updateVetement(Vetement vet);
	void deleteVetement(Vetement vet);
	void deleteVetementById(Long id);
	Vetement getVetement(Long id);
	List<Vetement> getAllVetements();
	List<Vetement> findByNomVetement(String nom);
	List<Vetement> findByNomVetementContains(String nom);
	List<Vetement> findByNomPrix (String nom, Double prix);
	List<Vetement> findByCategorie (Marque marque);
	List<Vetement> findByMarqueIdMarque(Long id);
	List<Vetement> findByOrderByNomVetementAsc();
	List<Vetement> trierProduitsNomsPrix();

}
