package com.mootez.vetements.repos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.mootez.vetements.entities.Marque;
import com.mootez.vetements.entities.Vetement;

@RepositoryRestResource(path = "rest")
public interface VetementRepository extends JpaRepository<Vetement, Long> {
	
	List<Vetement> findByNomVetement(String nom);
	List<Vetement> findByNomVetementLike(String nom);
	List<Vetement> findByNomVetementContains(String nom);
	
	/*@Query("select v from Vetement v where v.nomVetement like %?1 and v.prixVetement > ?2")
	List<Vetement> findByNomPrix (String nom, Double prix);*/
	
	@Query("select v from Vetement v where v.nomVetement like %:nom and v.prixVetement > :prix")
	List<Vetement> findByNomPrix (@Param("nom") String nom,@Param("prix") Double prix);
	
	@Query("select v from Vetement v where v.marque = ?1")
	List<Vetement> findByCategorie (Marque marque);
	
	List<Vetement> findByMarqueIdMarque(Long id);
	
	List<Vetement> findByOrderByNomVetementAsc();
	
	@Query("select v from Vetement v order by v.nomVetement ASC, v.prixVetement DESC")
	List<Vetement> trierVetementsNomsPrix ();
	

}
