package com.mootez.vetements.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mootez.vetements.entities.Marque;
import com.mootez.vetements.entities.Vetement;
import com.mootez.vetements.repos.VetementRepository;

@Service
public class VetementServiceImpl implements VetementService{
	
	@Autowired
	VetementRepository vetementRepository;

	@Override
	public Vetement saveVetement(Vetement vet) {
		return vetementRepository.save(vet);
	}

	@Override
	public Vetement updateVetement(Vetement vet) {
		return vetementRepository.save(vet);
	}

	@Override
	public void deleteVetement(Vetement vet) {
		vetementRepository.delete(vet);
		
	}

	@Override
	public void deleteVetementById(Long id) {
		vetementRepository.deleteById(id);
		
	}

	@Override
	public Vetement getVetement(Long id) {
		return vetementRepository.findById(id).get();
	}

	@Override
	public List<Vetement> getAllVetements() {
		
		return vetementRepository.findAll();
	}

	@Override
	public List<Vetement> findByNomVetement(String nom) {
		
		return vetementRepository.findByNomVetement(nom);
	}

	@Override
	public List<Vetement> findByNomVetementContains(String nom) {
		
		return vetementRepository.findByNomVetementContains(nom);
	}

	@Override
	public List<Vetement> findByNomPrix(String nom, Double prix) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Vetement> findByCategorie(Marque marque) {
		
		return vetementRepository.findByCategorie(marque);
	}

	@Override
	public List<Vetement> findByMarqueIdMarque(Long id) {
		
		return vetementRepository.findByMarqueIdMarque(id);
	}

	@Override
	public List<Vetement> findByOrderByNomVetementAsc() {
		
		return vetementRepository.findByOrderByNomVetementAsc();
	}

	@Override
	public List<Vetement> trierProduitsNomsPrix() {
		
		return vetementRepository.trierVetementsNomsPrix();
	}

}
