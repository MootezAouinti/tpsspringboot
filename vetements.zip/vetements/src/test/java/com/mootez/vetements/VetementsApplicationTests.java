package com.mootez.vetements;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.mootez.vetements.entities.Marque;
import com.mootez.vetements.entities.Vetement;
import com.mootez.vetements.repos.VetementRepository;

@SpringBootTest
class VetementsApplicationTests {

	@Autowired
	private VetementRepository vetementRepository;
	@Test
	public void testCreateVetement() {
	Vetement vet = new Vetement("Pantalon",62.900,"Femme");
	vetementRepository.save(vet );
	}
	
	@Test
	public void testFindProduit()
	{
	Vetement vet = vetementRepository.findById(1L).get();

	System.out.println(vet);
	}
	
	@Test
	public void testUpdateVetement()
	{
	Vetement vet = vetementRepository.findById(1L).get();
	vet.setPrixVetement(89.0);
	vetementRepository.save(vet);
	}
	
	@Test
	public void testDeleteVetement()
	{
	vetementRepository.deleteById(1L);
	}
	
	@Test
	public void testFindAllVetements()
	{
		
	List<Vetement> vets = 	vetementRepository.findAll();
	
	for (Vetement v:vets)
		System.out.println(v);
	
	}
	
	@Test
	public void testFindVetementByNom()
	{
	List<Vetement> vets = vetementRepository.findByNomVetement("pantalon");

	for (Vetement v:vets)
		System.out.println(v);
	}
	
	@Test
	public void testFindVetementByNomLike()
	{
	List<Vetement> vets = vetementRepository.findByNomVetementLike("p");

	for (Vetement v:vets)
		System.out.println(v);
	}
	
	@Test
	public void testFindVetementByNomContains()
	{
	List<Vetement> vets = vetementRepository.findByNomVetementContains("t");

	for (Vetement v:vets)
		System.out.println(v);
	}
	
	@Test
	public void testfindByNomPrix()
	{
	List<Vetement> vets = vetementRepository.findByNomPrix("veste", 50.0);
	for (Vetement v : vets)
	{
	System.out.println(v);
	}
	
	

	}
	@Test
	public void testfindByCategorie()
	{
	Marque mq = new Marque();
	mq.setIdMarque(1L);
	List<Vetement> vets = vetementRepository.findByCategorie(mq);
	for (Vetement v : vets)
	{
	System.out.println(v);
	}

	}
	@Test
	public void findByMarqueIdMarque()
	{
	List<Vetement> vets = vetementRepository.findByMarqueIdMarque(1L);
	for (Vetement v : vets)
	{
	System.out.println(v);
	}

	}
	
	@Test
	public void testfindByOrderByNomVetementAsc()
	{
	List<Vetement> vets = vetementRepository.findByOrderByNomVetementAsc();
	for (Vetement v : vets)
	{
	System.out.println(v);
	}

	}
	
	@Test
	public void testTrierVetementsNomsPrix()
	{
	List<Vetement> vets = vetementRepository.trierVetementsNomsPrix();
	for (Vetement v : vets)
	{
	System.out.println(v);
	}

	}

}
